function createNode(str){let tempNode=document.createElement('div');tempNode.innerHTML=str;return tempNode.firstChild;}
function getScrollTop(){let scrollTop=0;if(document.documentElement&&document.documentElement.scrollTop){scrollTop=document.documentElement.scrollTop;}else if(document.body){scrollTop=document.body.scrollTop;}
return scrollTop;}
function getParentTag(startTag,findTag){if('BODY'!=startTag.nodeName){if(startTag.className)
if(startTag.className.indexOf(findTag)!=-1){return startTag;}
return getParentTag(startTag.parentElement,findTag)}
else{return null;}}
var debounce=function(func,threshold,execAsap){var timeout;return function debounced(){var obj=this,args=arguments;function delayed(){if(!execAsap)
func.apply(obj,args);timeout=null;};if(timeout)
clearTimeout(timeout);else if(execAsap)
func.apply(obj,args);timeout=setTimeout(delayed,threshold||100);};}
function initnovImg(){var novImgCode='<div class="nov-table"><p></p><img id="nov-table-img" style="pointer-events: none;" src="" /><button type="button">&times;</button></div>';document.body.insertBefore(createNode(novImgCode),document.body.firstElementChild);}
function initnovImgJudge(novImgJudge){if(!novImgJudge){initnovImg();return 1;}
return 0;}
function novAltText(thisDom){if(typeof(thisDom.getAttribute("alt"))!="undefined")document.querySelector(".nov-table p").innerHTML=thisDom.getAttribute("alt");}
function novResponsive(n){var window_width=document.body.clientWidth;if(n==1){if(window_width>=1200)return 40;else if(window_width>=992)return 30;else if(window_width>=450)return 20;else return 10;}else if(n==2){if(window_width>=1200)return 25;else if(window_width>=992)return 20;else if(window_width>=450)return 10;else return 1;}}
function novCloseMethod(novTable,defaultC){document.querySelector(".nov-table button").onclick=function(){var novTableImg=document.getElementById("nov-table-img");novTable.style.display="none";novTableImg.style.width="auto";novTableImg.style.height="auto";novTable.style.background=defaultC;novTable.querySelector("p").innerHTML="";document.body.style.overflowY="auto";}}
function novImgCenter(novTableImg){novTableImg.style.top=(document.body.clientHeight-parseFloat(getComputedStyle(novTableImg).height))/2+"px";}
function novSize(novTable,novTableImg){var imgWidthScale;var imgHeightScale;var novTableImgHeight=parseFloat(getComputedStyle(novTableImg).height);var novTableImgWidth=parseFloat(getComputedStyle(novTableImg).width);if(novTableImgWidth>novTableImgHeight){imgWidthScale=novResponsive(1);imgHeightScale=(novTableImgHeight/novTableImgWidth)*novResponsive(1);}else{imgWidthScale=(novTableImgWidth/novTableImgHeight)*novResponsive(1);imgHeightScale=novResponsive(1);}
var w=0,h=0;for(;;){if(w<document.body.clientWidth-novResponsive(2)*10){w+=imgWidthScale;}else{break;}
if(h<document.body.clientHeight-novResponsive(2)*10){h+=imgHeightScale;}else{break;}}
novTableImg.style.width=w+"px";novTableImg.style.height=h+"px";}
function novScrollMethod(novTable,Domthis){var issafariBrowser=/Safari/.test(navigator.userAgent)&&!/Chrome/.test(navigator.userAgent);if((Domthis.getAttribute("noScroll")!=null||getParentTag(Domthis,"nov-img-box").getAttribute("noScroll")!=null)&&(!issafariBrowser)){document.body.style.overflowY="hidden";document.querySelector(".nov-table").style.width="100%";}else{window.onscroll=function(){novTable.style.top=getScrollTop()+"px";}
document.body.style.overflowY="auto";}}
function novMoblie(){var novTable=document.querySelector(".nov-table");if(document.body.clientWidth<=648&&getComputedStyle(novTable).display=="block"){novTable.style.height=window.innerHeight+"px";}}
function resizeFn(){var novTable=document.querySelector(".nov-table");window.onresize=debounce(function(){novTable.style.width=document.body.clientWidth+"px";novTable.style.height=document.body.clientHeight+"px";novTable.style.top=getScrollTop()+"px";novMoblie();},100,false);}
function colorChange(Domthis,defaultC){var NodeSingleColor=Domthis.getAttribute("novBackground");var NodeBoxColor=getParentTag(Domthis,"nov-img-box").getAttribute("novBackground");var novTable=document.querySelector(".nov-table");if(NodeSingleColor){novTable.style.background=NodeSingleColor;}else if(NodeBoxColor){novTable.style.background=NodeBoxColor;}else{novTable.style.background=defaultC;}}
function novFunction(Domthis,defaultC){if(Domthis.className.indexOf('nov-no-active')!=-1)return 0;var novTableImg=document.getElementById("nov-table-img");var novTable=document.querySelector(".nov-table");novTableImg.setAttribute("src",Domthis.getAttribute("src"));novTable.style.width=document.body.clientWidth+"px";novTable.style.height=document.body.clientHeight+500+"px";novTable.style.top=getScrollTop()+"px";novTable.style.display="block";novScrollMethod(novTable,Domthis);colorChange(Domthis,defaultC);resizeFn();novMoblie();novSize(novTable,novTableImg);novImgCenter(novTableImg);novCloseMethod(novTable,defaultC);}
function novImg(){var novTable=document.querySelector(".nov-table");var defaultC=getComputedStyle(novTable).background;var novImgSingleImg=document.querySelectorAll(".nov-img-box img")
for(var i=0;i<novImgSingleImg.length;i++){novImgSingleImg[i].onclick=function(){novFunction(this,defaultC);}}}
function novImgSingleFn(){var novTable=document.querySelector(".nov-table");var defaultC=getComputedStyle(novTable).background;var novImgSingle=document.querySelectorAll(".nov-img-single");for(var i=0;i<novImgSingle.length;i++){novImgSingle[i].onclick=function(){novFunction(this,defaultC);}}}
(function novImgMain(){var novImgJudge=0;var novImgBox=document.querySelectorAll(".nov-img-box");var novImgSingle=document.querySelectorAll(".nov-img-single");if(novImgBox.length>0){novImgJudge=initnovImgJudge(novImgJudge);novImg();}
if(novImgSingle.length>0){novImgJudge=initnovImgJudge(novImgJudge);novImgSingleFn();}})();